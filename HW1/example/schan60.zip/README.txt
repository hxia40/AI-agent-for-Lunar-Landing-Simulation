This program is written under jython.

The 2 subfolders:
1. Solution - contains the python/jython code to run the assignment
2. BURLAP - Contains the Java BURLAP project and dependencies.

Running the easyGW.py, hardGW.py, and the varysize.py in the "Solution" folder will generate the results in it.

Special Credits: source code largely base on materials from http://github.com/JonathanTay/

